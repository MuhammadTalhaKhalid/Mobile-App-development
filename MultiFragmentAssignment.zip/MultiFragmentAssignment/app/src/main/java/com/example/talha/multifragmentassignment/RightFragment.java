package com.example.talha.multifragmentassignment;


import android.app.Fragment;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;



public class RightFragment extends Fragment {
    TextView text;
    TextView Desc;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view=inflater.inflate(R.layout.right_fragment,container,false);
        text=(TextView)view.findViewById(R.id.tv1);
        Desc=(TextView)view.findViewById(R.id.tv2);

        return view;
    }
    public void change(String txt1,String txt2){

        text.setText(txt1);
        Desc.setText(txt2);
        //txt1.setTxt(text.setText(txt1,Decp));

    }

}
