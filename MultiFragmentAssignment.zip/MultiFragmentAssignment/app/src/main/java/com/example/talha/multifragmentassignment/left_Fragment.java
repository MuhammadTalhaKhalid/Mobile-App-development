package com.example.talha.multifragmentassignment;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.app.ListFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class left_Fragment extends ListFragment {
String [] MonthName = new String[] {"Janurary","Feb","March","Aprail","May","June","July","August","September","October","November","December"};
String [] MonthDesc = new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.left_frgment,container,false);
        ArrayAdapter<String> Adapter=new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,MonthName);
        setListAdapter(Adapter);
        // Inflate the layout for this fragment
        return view;

    }

    @Override
    public void onListItemClick(ListView l,View V, int pos, long id ) {
        RightFragment txt=(RightFragment)getFragmentManager().findFragmentById(R.id.fragment2);
        txt.change(MonthName[pos],"Month no "+MonthDesc[pos]);
        getListView().setSelector(android.R.color.holo_blue_dark);
    }
}
